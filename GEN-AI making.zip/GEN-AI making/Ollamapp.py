import os
from dotenv import load_dotenv
from langchain_community.llms import Ollama  # Ollama integration from langchain_community
import streamlit as st
from langchain.prompts import ChatPromptTemplate
from langchain.chains import LLMChain

# Load environment variables from .env file
load_dotenv()

# Retrieve API keys from environment variables
langchain_api_key = os.getenv("LANGCHAIN_API_KEY")
google_api_key = os.getenv("GOOGLE_API_KEY")

# Debugging: Print API key status
print(f"LANGCHAIN_API_KEY found: {bool(langchain_api_key)}")
print(f"GOOGLE_API_KEY found: {bool(google_api_key)}")

# Raise an error if keys are missing
if not langchain_api_key:
    raise ValueError("❌ LANGCHAIN_API_KEY not found! Check your .env file.")
if not google_api_key:
    raise ValueError("❌ GOOGLE_API_KEY not found! Check your .env file.")

# Ensure API keys are set in the environment
os.environ["LANGCHAIN_API_KEY"] = langchain_api_key
os.environ["GOOGLE_API_KEY"] = google_api_key

# Define a proper prompt template
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful AI assistant."),
    ("user", "{question}")  # Dynamic user input
])

# Use the correct model name
llm = Ollama(model="llama3.2")

# Create the chain
chain = LLMChain(prompt=prompt, llm=llm)

# Streamlit UI
st.title("Ollama Chat Bot")
input_text = st.text_input("Enter your question:")

if input_text:
    response = chain.run({"question": input_text})
    st.write(response)