from fastapi import FastAPI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_groq import ChatGroq
import os
from langserve import add_routes
from dotenv import load_dotenv
import logging

# Load environment variables
load_dotenv()

# Retrieve API key
groq_api_key = os.getenv("GROQ_API_KEY")

# Check if the API key is loaded correctly
if not groq_api_key:
    logging.error("❌ Error: GROQ_API_KEY not found! Please check your .env file.")
    raise ValueError("GROQ_API_KEY is missing. Ensure it's set in your .env file.")

# Initialize Groq model
try:
    model = ChatGroq(model="Deepseek-R1-Distill-Llama-70b", groq_api_key=groq_api_key)
except Exception as e:
    logging.error(f"❌ Error initializing Groq model: {e}")
    raise

## 1. Create Prompt Template
system_template = "Translate the following into {language}:"
prompt_template = ChatPromptTemplate.from_messages([
    ('system', system_template),
    ('user', '{text}')
])

# Define a custom parser to clean responses
class CustomStrOutputParser(StrOutputParser):
    def invoke(self, response):
        # Strip unnecessary thinking process from LLM output
        return response.split("</think>\n\n")[-1] if "</think>" in response else response

# Use the custom parser
parser = CustomStrOutputParser()

# Create chain
chain = prompt_template | model | parser

## App definition
app = FastAPI(
    title="Langchain Server",
    version="1.0",
    description="A simple API server using Langchain runnable interfaces"
)

## Adding chain routes
add_routes(
    app,
    chain,
    path="/chain"
)

# Run FastAPI server correctly
if __name__ == "__main__":
    logging.info("🚀 Starting FastAPI server on http://127.0.0.1:8000")
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
